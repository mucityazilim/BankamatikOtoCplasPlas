#include <iostream>
#include "YetkiliIslem.h"
#include "MusteriIslem.h"
#include "AnaMenu.h"

// Bankamatik Otomasyonu 
// Sad�k �AH�N- Bilgisayar M�hendisi

int main(int argc, char** argv) {

	AnaMenu nesne; 
	nesne.giris() ; 
	
	
	return 0;
}
